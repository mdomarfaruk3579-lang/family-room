import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { User } from './types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, loading: true, isAdmin: false });

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Check if user exists in db, if not create as 'user'
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        let role: 'admin' | 'user' = 'user';
        
        try {
          const userDoc = await getDoc(userDocRef);
          if (userDoc.exists()) {
            role = userDoc.data().role;
          } else {
            // Default admin check
            if (firebaseUser.email === 'mdomarfaruk3579@gmail.com' && firebaseUser.emailVerified) {
              role = 'admin';
              // We can't create it as admin directly unless the rule allows it, but the rule allows isAdmin() to do anything.
              // Since the user is the default admin, isAdmin() evaluates to true, so they can create it with role 'admin'.
              await setDoc(userDocRef, { email: firebaseUser.email, role: 'admin' });
            } else {
              await setDoc(userDocRef, { email: firebaseUser.email, role: 'user' });
            }
          }
        } catch (error) {
          console.error("Error fetching user role:", error);
          if (firebaseUser.email === 'mdomarfaruk3579@gmail.com' && firebaseUser.emailVerified) {
            role = 'admin';
          }
        }

        setUser({ uid: firebaseUser.uid, email: firebaseUser.email, role });
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, isAdmin: user?.role === 'admin' }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
