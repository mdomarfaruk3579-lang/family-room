import { useEffect, useState } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { Member } from '../types';
import { motion } from 'framer-motion';
import { Users, User, Baby, Heart, Activity, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Statistics() {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'members'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Member));
      setMembers(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#EAE6DF] border-t-[#1A3636]"></div>
      </div>
    );
  }

  const totalMembers = members.length;
  const grandpas = members.filter(m => m.type === 'grandpa').length;
  const grandmas = members.filter(m => m.type === 'grandma').length;
  const sons = members.filter(m => m.type === 'son').length;
  const daughters = members.filter(m => m.type === 'daughter').length;
  const spouses = members.filter(m => m.type === 'spouse').length;
  const grandchildren = members.filter(m => m.type === 'grandchild').length;
  const greatGrandchildren = members.filter(m => m.type === 'great-grandchild').length;
  const males = members.filter(m => m.gender === 'male').length;
  const females = members.filter(m => m.gender === 'female').length;

  const statCards = [
    { title: 'মোট সদস্য', count: totalMembers, icon: Users, color: 'bg-blue-50 text-blue-600 border-blue-200' },
    { title: 'দাদা-দাদি', count: grandpas + grandmas, icon: Heart, color: 'bg-rose-50 text-rose-600 border-rose-200' },
    { title: 'ছেলে', count: sons, icon: User, color: 'bg-indigo-50 text-indigo-600 border-indigo-200' },
    { title: 'মেয়ে', count: daughters, icon: User, color: 'bg-pink-50 text-pink-600 border-pink-200' },
    { title: 'স্ত্রী/স্বামী', count: spouses, icon: Heart, color: 'bg-purple-50 text-purple-600 border-purple-200' },
    { title: 'নাতি-নাতনি', count: grandchildren, icon: Baby, color: 'bg-emerald-50 text-emerald-600 border-emerald-200' },
    { title: 'নাতি-নাতনির সন্তান', count: greatGrandchildren, icon: Baby, color: 'bg-amber-50 text-amber-600 border-amber-200' },
    { title: 'পুরুষ', count: males, icon: Activity, color: 'bg-cyan-50 text-cyan-600 border-cyan-200' },
    { title: 'মহিলা', count: females, icon: Activity, color: 'bg-fuchsia-50 text-fuchsia-600 border-fuchsia-200' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-6xl mx-auto py-8 px-4"
    >
      <Link to="/" className="inline-flex items-center gap-2 text-[#1A3636] hover:text-[#C19A6B] mb-6 font-medium transition-colors">
        <ArrowLeft className="w-5 h-5" /> ফ্যামিলি ট্রিতে ফিরে যান
      </Link>

      <div className="text-center mb-12">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl sm:text-5xl font-serif font-bold text-[#1A3636] mb-4"
        >
          পরিবারের পরিসংখ্যান
        </motion.h1>
        <div className="w-24 h-1 bg-[#C19A6B] mx-auto rounded-full"></div>
        <p className="mt-6 text-[#736B65] max-w-2xl mx-auto text-lg">
          আমাদের ক্রমবর্ধমান পরিবারের একটি বিস্তারিত পরিসংখ্যান। দেখুন কীভাবে আমাদের পরিবার প্রজন্মের পর প্রজন্ম ধরে বিস্তৃত হয়েছে।
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className={`p-6 rounded-3xl border shadow-sm flex items-center gap-6 ${stat.color} bg-opacity-50 backdrop-blur-sm hover:shadow-md transition-shadow`}
            >
              <div className={`p-4 rounded-2xl bg-white shadow-sm`}>
                <Icon className="w-8 h-8" />
              </div>
              <div>
                <p className="text-sm font-medium opacity-80 mb-1">{stat.title}</p>
                <h3 className="text-4xl font-bold font-serif">{stat.count}</h3>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
