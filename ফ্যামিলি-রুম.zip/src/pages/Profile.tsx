import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { doc, onSnapshot, collection, query, where } from 'firebase/firestore';
import { db } from '../firebase';
import { Member } from '../types';
import { Calendar, Info, Image as ImageIcon, Edit, ArrowLeft, Heart, Users, Plus } from 'lucide-react';
import { useAuth } from '../AuthContext';
import MemberCard from '../components/MemberCard';

import { motion } from 'framer-motion';

export default function Profile() {
  const { id } = useParams<{ id: string }>();
  const [member, setMember] = useState<Member | null>(null);
  const [spouse, setSpouse] = useState<Member | null>(null);
  const [children, setChildren] = useState<Member[]>([]);
  const { isAdmin } = useAuth();

  useEffect(() => {
    if (!id) return;

    // Listen to main member
    const unsubMember = onSnapshot(doc(db, 'members', id), (docSnap) => {
      if (docSnap.exists()) {
        const data = { id: docSnap.id, ...docSnap.data() } as Member;
        setMember(data);
        
        // Listen to spouse (either this member is the spouse, or the other member has this member as spouse)
        const qSpouse = query(collection(db, 'members'), where('spouseId', '==', id));
        const unsubSpouse1 = onSnapshot(qSpouse, (snap) => {
          if (!snap.empty) {
            setSpouse({ id: snap.docs[0].id, ...snap.docs[0].data() } as Member);
          } else if (data.spouseId) {
            // If this member has a spouseId, fetch that spouse
            const unsubSpouse2 = onSnapshot(doc(db, 'members', data.spouseId), (spouseDoc) => {
              if (spouseDoc.exists()) {
                setSpouse({ id: spouseDoc.id, ...spouseDoc.data() } as Member);
              }
            });
            return () => unsubSpouse2();
          } else {
            setSpouse(null);
          }
        });

        // Listen to children (where parentId is this member or their spouse)
        const qChildren = query(collection(db, 'members'), where('parentId', '==', id));
        const unsubChildren1 = onSnapshot(qChildren, (snap) => {
          let kids = snap.docs.map(d => ({ id: d.id, ...d.data() } as Member));
          setChildren(kids.sort((a, b) => a.order - b.order));
        });

        return () => {
          unsubSpouse1();
          unsubChildren1();
        };
      }
    });

    return () => unsubMember();
  }, [id]);

  if (!member) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#EAE6DF] border-t-[#1A3636]"></div>
      </div>
    );
  }

  const seed = encodeURIComponent(member.name || member.role || 'family');
  const avatarStyle = member.gender === 'female' ? 'lorelei' : 'micah';
  const avatarUrl = `https://api.dicebear.com/9.x/${avatarStyle}/svg?seed=${seed}&backgroundColor=EAE6DF`;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-4xl mx-auto py-8 px-4"
    >
      <Link to="/" className="inline-flex items-center gap-2 text-[#1A3636] hover:text-[#C19A6B] mb-6 font-medium transition-colors">
        <ArrowLeft className="w-5 h-5" /> Back to Family Tree
      </Link>

      <div className="bg-white rounded-3xl shadow-lg p-8 border border-[#EAE6DF] relative">
        {isAdmin && (
          <Link 
            to={`/admin?edit=${member.id}`}
            className="absolute top-6 right-6 flex items-center gap-2 bg-[#C19A6B] text-white px-4 py-2 rounded-full hover:bg-[#a88358] transition-colors shadow-sm"
          >
            <Edit className="w-4 h-4" /> Edit Profile
          </Link>
        )}

        <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="w-48 h-48 rounded-full overflow-hidden border-4 border-[#EAE6DF] shadow-md shrink-0 bg-[#F9F8F6]"
          >
            {member.photoUrl ? (
              <img src={member.photoUrl} alt={member.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover p-2" />
            )}
          </motion.div>
          
          <div className="flex-1 text-center md:text-left">
            <motion.h1 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="text-4xl font-serif font-bold text-[#1A3636] mb-2"
            >
              {member.name}
            </motion.h1>
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="inline-block px-4 py-1.5 bg-[#EAE6DF] text-[#1A3636] rounded-full font-medium mb-4 tracking-wide border border-[#d8d2c9]"
            >
              {member.role}
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="flex flex-col gap-2 mb-6 text-[#5c5c5c]"
            >
              {member.birthYear && (
                <div className="flex items-center gap-2 justify-center md:justify-start">
                  <Calendar className="w-4 h-4 text-[#C19A6B]" />
                  <span>Born: {member.birthYear}</span>
                </div>
              )}
              {member.deathYear && (
                <div className="flex items-center gap-2 justify-center md:justify-start">
                  <Calendar className="w-4 h-4 text-[#C19A6B]" />
                  <span>Died: {member.deathYear}</span>
                </div>
              )}
            </motion.div>
            
            {member.bio && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="bg-[#F9F8F6] p-4 rounded-xl border border-[#EAE6DF] text-left"
              >
                <div className="flex items-center gap-2 font-semibold text-[#1A3636] mb-2">
                  <Info className="w-4 h-4" />
                  <span>About</span>
                </div>
                <p className="text-[#4a4a4a] leading-relaxed">{member.bio}</p>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Immediate Family Section - Hidden for Grandparents */}
      {member.type !== 'grandpa' && member.type !== 'grandma' && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="mt-12"
        >
          <h2 className="text-2xl font-serif font-bold text-[#1A3636] mb-6 flex items-center gap-2 border-b border-[#EAE6DF] pb-2">
            <Heart className="w-6 h-6 text-[#C19A6B]" /> Immediate Family
          </h2>
          
          <div className="flex flex-wrap gap-8 justify-center md:justify-start">
            <div className="flex flex-col items-center">
              <span className="text-sm font-medium text-[#C19A6B] mb-2">Spouse</span>
              {spouse ? (
                <MemberCard member={spouse} />
              ) : isAdmin ? (
                <Link to={`/admin?addSpouseFor=${member.id}`} className="w-20 sm:w-24 h-24 sm:h-28 rounded-2xl border-2 border-dashed border-[#C19A6B] flex flex-col items-center justify-center text-[#C19A6B] hover:bg-[#F9F8F6] transition-colors">
                  <Plus className="w-6 h-6 mb-1" />
                  <span className="text-[10px] font-medium">Add Spouse</span>
                </Link>
              ) : (
                <p className="text-[#888] italic text-sm mt-4">Not added</p>
              )}
            </div>
            
            <div className="flex flex-col items-center md:items-start w-full md:w-auto mt-6 md:mt-0">
              <span className="text-sm font-medium text-[#C19A6B] mb-2 flex items-center gap-1">
                <Users className="w-4 h-4" /> Children ({children.length})
              </span>
              <div className="flex flex-wrap gap-4 justify-center">
                {children.map(child => (
                  <MemberCard key={child.id} member={child} />
                ))}
                {isAdmin && (
                  <Link to={`/admin?addChildFor=${member.id}`} className="w-20 sm:w-24 h-24 sm:h-28 rounded-2xl border-2 border-dashed border-[#C19A6B] flex flex-col items-center justify-center text-[#C19A6B] hover:bg-[#F9F8F6] transition-colors">
                    <Plus className="w-6 h-6 mb-1" />
                    <span className="text-[10px] font-medium">Add Child</span>
                  </Link>
                )}
              </div>
              {!isAdmin && children.length === 0 && (
                <p className="text-[#888] italic text-sm mt-4">No children added</p>
              )}
            </div>
          </div>
        </motion.div>
      )}

      {/* Gallery Section */}
      {member.gallery && member.gallery.length > 0 && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-12"
        >
          <h2 className="text-2xl font-serif font-bold text-[#1A3636] mb-6 flex items-center gap-2 border-b border-[#EAE6DF] pb-2">
            <ImageIcon className="w-6 h-6 text-[#C19A6B]" /> Photo Gallery
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {member.gallery.map((url, idx) => (
              <motion.div 
                key={idx} 
                whileHover={{ scale: 1.05 }}
                className="aspect-square rounded-2xl overflow-hidden shadow-sm border border-[#EAE6DF]"
              >
                <img src={url} alt={`Gallery ${idx}`} className="w-full h-full object-cover hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
