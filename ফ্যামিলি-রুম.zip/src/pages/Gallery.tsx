import { useEffect, useState } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db } from '../firebase';
import { Member } from '../types';
import { Image as ImageIcon } from 'lucide-react';

import { motion } from 'framer-motion';

export default function Gallery() {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'members'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Member));
      setMembers(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#EAE6DF] border-t-[#1A3636]"></div>
      </div>
    );
  }

  // Extract all gallery images from all members
  const allPhotos: { url: string; memberName: string; memberId: string }[] = [];
  members.forEach(member => {
    if (member.gallery && member.gallery.length > 0) {
      member.gallery.forEach(url => {
        allPhotos.push({ url, memberName: member.name || member.role || 'Family Member', memberId: member.id });
      });
    }
  });

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto py-8 px-4"
    >
      <div className="text-center mb-12">
        <motion.h1 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-4xl font-serif font-bold text-[#1A3636] mb-4 flex items-center justify-center gap-3"
        >
          <ImageIcon className="w-8 h-8 text-[#C19A6B]" /> Family Gallery
        </motion.h1>
        <motion.p 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-[#736B65] max-w-2xl mx-auto"
        >
          A collection of memories from all our family members.
        </motion.p>
      </div>

      {allPhotos.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {allPhotos.map((photo, idx) => (
            <motion.div 
              key={idx} 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: idx * 0.05 }}
              whileHover={{ y: -5 }}
              className="group relative aspect-square rounded-3xl overflow-hidden shadow-sm border border-[#EAE6DF] bg-white"
            >
              <img 
                src={photo.url} 
                alt={`Gallery ${idx}`} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                referrerPolicy="no-referrer" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                <span className="text-white font-medium text-sm drop-shadow-md">{photo.memberName}</span>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-20 bg-white rounded-3xl border border-[#EAE6DF] shadow-sm"
        >
          <ImageIcon className="w-16 h-16 mx-auto text-[#d8d2c9] mb-4" />
          <h3 className="text-xl font-serif font-bold text-[#1A3636] mb-2">No Photos Yet</h3>
          <p className="text-[#888]">Photos added to member profiles will appear here.</p>
        </motion.div>
      )}
    </motion.div>
  );
}
