import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, doc, setDoc, deleteDoc, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { AboutPost } from '../types';
import { useAuth } from '../AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit2, Trash2, Image as ImageIcon, Save, X, Info } from 'lucide-react';

export default function AboutUs() {
  const { isAdmin } = useAuth();
  const [posts, setPosts] = useState<AboutPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingPost, setEditingPost] = useState<Partial<AboutPost> | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ text: string, type: 'success' | 'error' } | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  useEffect(() => {
    const q = query(collection(db, 'about_posts'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AboutPost));
      setPosts(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleSave = async () => {
    if (!editingPost?.title || !editingPost?.content) {
      setMessage({ text: 'শিরোনাম এবং বিষয়বস্তু আবশ্যক', type: 'error' });
      return;
    }

    setSaving(true);
    try {
      const postRef = editingPost.id 
        ? doc(db, 'about_posts', editingPost.id) 
        : doc(collection(db, 'about_posts'));
      
      const { id, ...postData } = editingPost;
      
      const dataToSave: any = {
        title: postData.title,
        content: postData.content,
        order: editingPost.order || (editingPost.id ? 0 : posts.length + 1),
        createdAt: editingPost.createdAt || Date.now(),
      };

      if (postData.photoUrl) dataToSave.photoUrl = postData.photoUrl;

      await setDoc(postRef, dataToSave, { merge: true });
      setEditingPost(null);
      setMessage({ text: 'পোস্ট সফলভাবে সেভ হয়েছে!', type: 'success' });
    } catch (error: any) {
      console.error("Error saving post:", error);
      setMessage({ text: `পোস্ট সেভ করতে সমস্যা হয়েছে: ${error.message}`, type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'about_posts', id));
      setDeleteConfirmId(null);
      setMessage({ text: 'পোস্ট সফলভাবে ডিলিট হয়েছে!', type: 'success' });
    } catch (error) {
      console.error("Error deleting post:", error);
      setMessage({ text: 'পোস্ট ডিলিট করতে সমস্যা হয়েছে', type: 'error' });
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setMessage({ text: 'ফাইলটি অনেক বড় (সর্বোচ্চ ৫ মেগাবাইট)', type: 'error' });
      return;
    }

    setUploading(true);
    setUploadProgress(10);
    
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          setUploadProgress(50);
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const MAX_WIDTH = 1200;
          const MAX_HEIGHT = 1200;
          
          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
          
          setEditingPost(prev => {
            if (!prev) return prev;
            return { ...prev, photoUrl: dataUrl };
          });
          
          setUploading(false);
          setUploadProgress(100);
          setMessage({ text: 'ছবি সফলভাবে প্রসেস হয়েছে!', type: 'success' });
          setTimeout(() => setUploadProgress(0), 1000);
        };
      };
    } catch (error: any) {
      console.error("Error setting up upload:", error);
      setMessage({ text: `সমস্যা হয়েছে: ${error.message}`, type: 'error' });
      setUploading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#EAE6DF] border-t-[#1A3636]"></div>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-4xl mx-auto py-8 px-4"
    >
      <div className="flex flex-col sm:flex-row justify-between items-center mb-12 gap-4">
        <div className="text-center sm:text-left">
          <motion.h1 
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="text-4xl sm:text-5xl font-serif font-bold text-[#1A3636] mb-4"
          >
            আমাদের সম্পর্কে
          </motion.h1>
          <div className="w-24 h-1 bg-[#C19A6B] rounded-full mx-auto sm:mx-0"></div>
        </div>
        
        {isAdmin && (
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setEditingPost({ order: posts.length + 1 })}
            className="flex items-center gap-2 bg-[#1A3636] text-white px-5 py-2.5 rounded-full hover:bg-[#1C1816] transition-colors shadow-md"
          >
            <Plus className="w-5 h-5" />
            পোস্ট যোগ করুন
          </motion.button>
        )}
      </div>

      <AnimatePresence>
        {message && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`mb-6 p-4 rounded-xl text-center font-medium shadow-sm border ${
              message.type === 'success' ? 'bg-green-50 text-green-700 border-green-100' : 'bg-red-50 text-red-700 border-red-100'
            }`}
          >
            {message.text}
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deleteConfirmId && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white p-6 rounded-3xl max-w-sm w-full shadow-2xl"
            >
              <h3 className="text-xl font-serif font-bold text-[#1A3636] mb-2">ডিলিট নিশ্চিত করুন</h3>
              <p className="text-[#736B65] mb-6">আপনি কি নিশ্চিত যে আপনি এই পোস্টটি ডিলিট করতে চান? এই কাজটি আর বাতিল করা যাবে না।</p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 py-2.5 border border-[#d8d2c9] rounded-full hover:bg-[#F9F8F6] font-medium transition-colors"
                >
                  বাতিল
                </button>
                <button 
                  onClick={() => deleteConfirmId && handleDelete(deleteConfirmId)}
                  className="flex-1 py-2.5 bg-red-500 text-white rounded-full hover:bg-red-600 font-medium transition-colors"
                >
                  ডিলিট
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {editingPost && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white p-6 sm:p-8 rounded-3xl shadow-lg mb-12 border border-[#EAE6DF] overflow-hidden"
          >
            <div className="flex justify-between items-center mb-6 border-b border-[#EAE6DF] pb-4">
              <h2 className="text-2xl font-serif font-bold text-[#1A3636]">
                {editingPost.id ? 'পোস্ট এডিট করুন' : 'নতুন পোস্ট'}
              </h2>
              <button onClick={() => setEditingPost(null)} className="text-[#C19A6B] hover:text-[#a88358] transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="grid grid-cols-1 gap-6">
              <div>
                <label className="block text-sm font-medium text-[#1A3636] mb-1">শিরোনাম *</label>
                <input 
                  type="text" 
                  value={editingPost.title || ''} 
                  onChange={e => setEditingPost({...editingPost, title: e.target.value})}
                  className="w-full p-3 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
                  placeholder="একটি শিরোনাম লিখুন..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#1A3636] mb-1">বিষয়বস্তু *</label>
                <textarea 
                  value={editingPost.content || ''} 
                  onChange={e => setEditingPost({...editingPost, content: e.target.value})}
                  className="w-full p-3 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6] min-h-[200px]"
                  placeholder="আপনার গল্প এখানে লিখুন..."
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-[#1A3636] mb-1">ছবি (ঐচ্ছিক)</label>
                <div className="flex flex-col gap-4">
                  {editingPost.photoUrl && (
                    <div className="relative w-full max-w-md rounded-xl overflow-hidden border border-[#EAE6DF]">
                      <img src={editingPost.photoUrl} alt="Preview" className="w-full h-auto object-cover" referrerPolicy="no-referrer" />
                      <button 
                        onClick={() => setEditingPost({...editingPost, photoUrl: undefined})}
                        className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 shadow-md hover:bg-red-600 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  <label className="cursor-pointer bg-[#EAE6DF] text-[#1A3636] px-5 py-3 rounded-xl hover:bg-[#d8d2c9] transition-colors flex items-center justify-center gap-2 font-medium border border-[#d8d2c9] border-dashed w-full max-w-md">
                    <ImageIcon className="w-5 h-5" />
                    {uploading ? 'আপলোড হচ্ছে...' : 'ছবি আপলোড করুন'}
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} disabled={uploading} />
                  </label>
                  {uploading && uploadProgress > 0 && uploadProgress < 100 && (
                    <div className="w-full max-w-md bg-gray-200 rounded-full h-1.5 mt-1">
                      <div className="bg-[#1A3636] h-1.5 rounded-full transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#1A3636] mb-1">ক্রম (Order)</label>
                <input 
                  type="number" 
                  value={editingPost.order || 0} 
                  onChange={e => setEditingPost({...editingPost, order: parseInt(e.target.value)})}
                  className="w-full p-3 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6] max-w-[150px]"
                />
              </div>
            </div>

            <div className="mt-8 flex justify-end gap-4 border-t border-[#EAE6DF] pt-6">
              <button 
                onClick={() => setEditingPost(null)}
                className="px-6 py-2.5 border border-[#d8d2c9] rounded-full hover:bg-[#F9F8F6] text-[#736B65] transition-colors font-medium"
              >
                বাতিল
              </button>
              <button 
                onClick={handleSave}
                disabled={saving}
                className="flex items-center gap-2 px-6 py-2.5 bg-[#1A3636] text-white rounded-full hover:bg-[#1C1816] transition-colors font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {saving ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <Save className="w-4 h-4" />
                )}
                {saving ? 'সেভ হচ্ছে...' : 'পোস্ট সেভ করুন'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col gap-12">
        {posts.length === 0 && !editingPost && (
          <div className="text-center py-16 bg-white rounded-3xl border border-[#EAE6DF] shadow-sm">
            <Info className="w-12 h-12 text-[#C19A6B] mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-serif font-bold text-[#1A3636] mb-2">এখনও কোনো পোস্ট নেই</h3>
            <p className="text-[#736B65]">আমাদের পরিবার সম্পর্কে আপডেট এবং গল্পের জন্য পরে আবার চেক করুন।</p>
          </div>
        )}

        {posts.map((post, index) => (
          <motion.article 
            key={post.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-3xl shadow-md border border-[#EAE6DF] overflow-hidden group"
          >
            {post.photoUrl && (
              <div className="w-full h-64 sm:h-80 lg:h-96 overflow-hidden bg-[#F9F8F6]">
                <img src={post.photoUrl} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" referrerPolicy="no-referrer" />
              </div>
            )}
            
            <div className="p-6 sm:p-10 relative">
              {isAdmin && (
                <div className="absolute top-6 right-6 flex gap-2">
                  <button 
                    onClick={() => setEditingPost(post)}
                    className="p-2 bg-white text-[#1A3636] hover:bg-[#EAE6DF] rounded-full shadow-sm border border-[#EAE6DF] transition-colors"
                    title="Edit"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setDeleteConfirmId(post.id)}
                    className="p-2 bg-white text-red-500 hover:bg-red-50 rounded-full shadow-sm border border-[#EAE6DF] transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
              
              <h2 className="text-3xl font-serif font-bold text-[#1A3636] mb-4 pr-20">{post.title}</h2>
              <div className="w-16 h-1 bg-[#C19A6B] rounded-full mb-6"></div>
              
              <div className="prose prose-lg max-w-none text-[#5C544D] whitespace-pre-wrap">
                {post.content}
              </div>
              
              <div className="mt-8 pt-6 border-t border-[#EAE6DF] text-sm text-[#888] font-medium">
                {new Date(post.createdAt).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </motion.div>
  );
}
