import { useEffect, useState, useMemo, useCallback } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { Member } from '../types';
import MemberCard from '../components/MemberCard';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();
  const [members, setMembers] = useState<Member[]>([]);
  const [activeParentId, setActiveParentId] = useState<string | null>(null);
  const [activeGrandchildId, setActiveGrandchildId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'members'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Member));
      setMembers(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const grandpas = useMemo(() => members.filter(m => m.type === 'grandpa'), [members]);
  const grandmas = useMemo(() => members.filter(m => m.type === 'grandma'), [members]);
  const sons = useMemo(() => members.filter(m => m.type === 'son'), [members]);
  const daughters = useMemo(() => members.filter(m => m.type === 'daughter'), [members]);
  const activeGrandchildren = useMemo(() => members.filter(m => m.type === 'grandchild' && m.parentId === activeParentId), [members, activeParentId]);

  const handleParentClick = useCallback((id: string) => {
    setActiveParentId(prev => prev === id ? null : id);
    setActiveGrandchildId(null);
  }, []);

  const handleGrandchildClick = useCallback((id: string) => {
    setActiveGrandchildId(prev => prev === id ? null : id);
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#EAE6DF] border-t-[#1A3636]"></div>
      </div>
    );
  }

  const renderGreatChildren = (grandchildId: string) => {
    if (activeGrandchildId !== grandchildId) return null;
    
    const greatGrandchildren = members.filter(m => m.type === 'great-grandchild' && m.parentId === grandchildId);
    if (greatGrandchildren.length === 0) return null;

    return (
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        style={{ willChange: 'opacity, height' }}
        className="flex flex-col items-center overflow-visible w-full mt-2 relative z-30"
      >
        <div className="w-px h-6 bg-[#C19A6B]"></div>
        
        <div className="relative flex flex-col gap-8 w-max items-center">
          <div className="inline-flex gap-1 sm:gap-4 relative w-max pt-6">
            {greatGrandchildren.length > 1 && (
              <div className="absolute top-0 left-0 right-0 px-[1.9rem] sm:px-[2.5rem] md:px-[3rem] -z-10">
                <div className="h-px bg-[#C19A6B] w-full"></div>
              </div>
            )}
            
            {greatGrandchildren.map(ggc => (
              <div key={ggc.id} className="flex flex-col items-center relative">
                <div className="w-px h-6 bg-[#C19A6B] absolute -top-6 -z-10"></div>
                <MemberCard member={ggc} />
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    );
  };

  const renderChildren = (parentId: string, parentType: string, parentName: string, index: number, total: number) => {
    if (activeParentId !== parentId || activeGrandchildren.length === 0) return null;
    
    // Determine position
    let position = 'middle';
    if (total > 1) {
      if (index === 0) position = 'left';
      else if (index === total - 1) position = 'right';
      else if (parentType === 'daughter' && index === 1) position = 'left';
    }

    let maxPerRow = 3;
    if (parentType === 'daughter') {
      if (position === 'left') {
        maxPerRow = 4; // Expand to the RIGHT side 4 rows/items
      } else if (parentName === 'মেয়ে 1' || parentName === 'মেয়ে 2') {
        maxPerRow = 6;
      } else {
        maxPerRow = 5;
      }
    }
    
    const rows = [];
    for (let i = 0; i < activeGrandchildren.length; i += maxPerRow) {
      rows.push(activeGrandchildren.slice(i, i + maxPerRow));
    }
    
    return (
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        style={{ willChange: 'opacity, height' }}
        className="flex flex-col items-center overflow-visible w-full mt-2 relative z-20"
      >
        <div className="w-px h-6 bg-[#C19A6B]"></div>
        
        <div className={`relative flex flex-col gap-8 w-max ${
          position === 'left' ? 'items-start translate-x-[calc(50%-1.9rem)] sm:translate-x-[calc(50%-2.5rem)] md:translate-x-[calc(50%-3rem)]' : 
          position === 'right' ? 'items-end -translate-x-[calc(50%-1.9rem)] sm:-translate-x-[calc(50%-2.5rem)] md:-translate-x-[calc(50%-3rem)]' : 
          'items-center'
        }`}>
          {rows.map((row, rowIndex) => (
            <div key={rowIndex} className="inline-flex gap-1 sm:gap-4 relative w-max pt-6">
              {/* Horizontal line for this row */}
              {row.length > 1 && (
                <div className="absolute top-0 left-0 right-0 px-[1.9rem] sm:px-[2.5rem] md:px-[3rem] -z-10">
                  <div className="h-px bg-[#C19A6B] w-full"></div>
                </div>
              )}
              
              {/* Vertical line connecting this row to the next row */}
              {rowIndex < rows.length - 1 && (
                <div className={`w-px bg-[#C19A6B] absolute top-0 -z-20 ${
                  position === 'left' ? 'left-[1.9rem] sm:left-[2.5rem] md:left-[3rem]' :
                  position === 'right' ? 'right-[1.9rem] sm:right-[2.5rem] md:right-[3rem]' :
                  'left-1/2 -translate-x-1/2'
                }`} style={{ height: 'calc(100% + 2rem)' }}></div>
              )}
              
              {row.map(gc => (
                <div key={gc.id} className="flex flex-col items-center relative">
                  {/* Vertical line connecting card to the horizontal line */}
                  <div className="w-px h-6 bg-[#C19A6B] absolute -top-6 -z-10"></div>
                  <MemberCard 
                    member={gc} 
                    isActive={activeGrandchildId === gc.id}
                    onClick={() => handleGrandchildClick(gc.id)}
                  />
                  {activeGrandchildId === gc.id && (
                    <motion.button
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      onClick={() => navigate(`/member/${gc.id}`)}
                      className="mt-2 text-[10px] bg-[#C19A6B] text-white px-2 py-0.5 rounded-full shadow-sm hover:bg-[#a88358] transition-colors"
                    >
                      বিস্তারিত দেখুন
                    </motion.button>
                  )}
                  <AnimatePresence>
                    {renderGreatChildren(gc.id)}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          ))}
        </div>
      </motion.div>
    );
  };

  return (
    <div className="flex flex-col items-center w-full max-w-full pb-20 pt-4">
      <div className="text-center mb-10">
        <Link to="/statistics" className="group inline-block">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl sm:text-6xl font-serif font-bold text-[#1A3636] mb-2 drop-shadow-sm group-hover:text-[#C19A6B] transition-colors"
          >
            ফ্যামিলি চার্ট
          </motion.h1>
          <div className="w-24 h-1 bg-[#C19A6B] mx-auto rounded-full group-hover:w-48 transition-all duration-300"></div>
        </Link>
      </div>

      <div className="max-w-screen-2xl mx-auto px-6 flex flex-col items-center w-full overflow-x-hidden">
        {/* Top Level: Dada & Dadi */}
        <div className="flex gap-4 sm:gap-12 relative z-10">
          {grandpas.map(m => <MemberCard key={m.id} member={m} />)}
          {grandmas.map(m => <MemberCard key={m.id} member={m} />)}
        </div>

        {/* Connection Line */}
        <div className="flex flex-col items-center my-2 relative w-full">
          <div className="w-px h-6 bg-[#C19A6B]"></div>
          <div className="bg-[#EAE6DF] text-[#1A3636] px-4 py-1 rounded-full font-serif font-bold text-sm sm:text-base shadow-sm border border-[#d8d2c9] z-10">
            ছেলে ও মেয়ে
          </div>
          <div className="w-px h-6 bg-[#C19A6B]"></div>
          {/* Horizontal Line */}
          <div className="w-[80%] md:w-[60%] h-px bg-[#C19A6B] absolute bottom-0"></div>
        </div>

        {/* Middle Level: Sons */}
        <div className="w-full mt-2">
          <div className="flex items-center justify-center gap-4 mb-2">
            <div className="h-px bg-[#C19A6B]/30 flex-grow max-w-[100px]"></div>
            <h3 className="text-center text-[#1A3636] font-serif font-bold text-2xl sm:text-3xl px-4">ছেলে</h3>
            <div className="h-px bg-[#C19A6B]/30 flex-grow max-w-[100px]"></div>
          </div>
          <div className="grid grid-cols-4 sm:grid-cols-5 gap-1 sm:gap-6 px-1 w-full max-w-full mx-auto justify-items-center">
            {sons.map((m, index) => (
              <div key={m.id} className="flex flex-col items-center w-full">
                <div className="w-px h-4 sm:h-6 bg-[#C19A6B] mb-0"></div>
                <MemberCard 
                  member={m} 
                  isActive={activeParentId === m.id}
                  onClick={() => handleParentClick(m.id)}
                />
                {activeParentId === m.id && (
                  <motion.button
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    onClick={() => navigate(`/member/${m.id}`)}
                    className="mt-2 text-[10px] bg-[#C19A6B] text-white px-2 py-0.5 rounded-full shadow-sm hover:bg-[#a88358] transition-colors"
                  >
                    বিস্তারিত দেখুন
                  </motion.button>
                )}
                <AnimatePresence>
                  {renderChildren(m.id, m.type, m.name, index, sons.length)}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>

        {/* Middle Level: Daughters */}
        {daughters.length > 0 && (
          <div className="w-full mt-10">
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="h-px bg-[#C19A6B]/30 flex-grow max-w-[100px]"></div>
              <h3 className="text-center text-[#1A3636] font-serif font-bold text-2xl sm:text-3xl px-4">মেয়ে</h3>
              <div className="h-px bg-[#C19A6B]/30 flex-grow max-w-[100px]"></div>
            </div>
            <div className="grid grid-cols-5 gap-1 sm:gap-6 px-1 w-full max-w-full mx-auto justify-items-center">
              {daughters.map((m, index) => (
                <div key={m.id} className="flex flex-col items-center w-full">
                  <div className="w-px h-4 sm:h-6 bg-[#C19A6B] mb-0"></div>
                  <MemberCard 
                    member={m} 
                    isActive={activeParentId === m.id}
                    onClick={() => handleParentClick(m.id)}
                  />
                  {activeParentId === m.id && (
                    <motion.button
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      onClick={() => navigate(`/member/${m.id}`)}
                      className="mt-2 text-[10px] bg-[#C19A6B] text-white px-2 py-0.5 rounded-full shadow-sm hover:bg-[#a88358] transition-colors"
                    >
                      বিস্তারিত দেখুন
                    </motion.button>
                  )}
                  <AnimatePresence>
                    {renderChildren(m.id, m.type, m.name, index, daughters.length)}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
