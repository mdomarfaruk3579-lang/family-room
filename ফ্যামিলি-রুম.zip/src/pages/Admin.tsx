import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, doc, setDoc, deleteDoc, query, orderBy } from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { Member } from '../types';
import { useAuth } from '../AuthContext';
import { Plus, Edit2, Trash2, Image as ImageIcon, Save, X, ArrowUp, ArrowDown } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

export default function Admin() {
  const { isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const editId = searchParams.get('edit');
  const addSpouseFor = searchParams.get('addSpouseFor');
  const addChildFor = searchParams.get('addChildFor');
  
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingMember, setEditingMember] = useState<Partial<Member> | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ text: string, type: 'success' | 'error' } | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  useEffect(() => {
    if (!authLoading && !isAdmin) {
      navigate('/');
    }
  }, [isAdmin, authLoading, navigate]);

  useEffect(() => {
    if (!isAdmin) return;
    const q = query(collection(db, 'members'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Member));
      setMembers(data);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [isAdmin]);

  useEffect(() => {
    if (members.length > 0) {
      if (editId) {
        const memberToEdit = members.find(m => m.id === editId);
        if (memberToEdit) {
          setEditingMember(memberToEdit);
        }
        setSearchParams({});
      } else if (addSpouseFor) {
        setEditingMember({ type: 'spouse', spouseId: addSpouseFor, order: 0, gender: 'female' });
        setSearchParams({});
      } else if (addChildFor) {
        const parentMember = members.find(m => m.id === addChildFor);
        const childType = parentMember?.type === 'grandchild' ? 'great-grandchild' : 'grandchild';
        setEditingMember({ type: childType, parentId: addChildFor, order: 0, gender: 'male' });
        setSearchParams({});
      }
    }
  }, [editId, addSpouseFor, addChildFor, members, setSearchParams]);

  const handleMove = async (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= members.length) return;

    const member1 = members[index];
    const member2 = members[newIndex];

    try {
      const order1 = member1.order;
      const order2 = member2.order;

      // If orders are the same, we need to force a difference
      const finalOrder1 = order1 === order2 ? (direction === 'up' ? order2 - 1 : order2 + 1) : order2;
      const finalOrder2 = order1;

      await Promise.all([
        setDoc(doc(db, 'members', member1.id), { order: finalOrder1 }, { merge: true }),
        setDoc(doc(db, 'members', member2.id), { order: finalOrder2 }, { merge: true })
      ]);
      
      setMessage({ text: 'Position updated!', type: 'success' });
    } catch (error) {
      console.error("Error reordering:", error);
      setMessage({ text: 'Error updating position', type: 'error' });
    }
  };

  const handleSave = async () => {
    if (!editingMember?.name || !editingMember?.role || !editingMember?.type) {
      setMessage({ text: 'Name, Role, and Type are required', type: 'error' });
      return;
    }

    setSaving(true);
    try {
      const memberRef = editingMember.id 
        ? doc(db, 'members', editingMember.id) 
        : doc(collection(db, 'members'));
      
      const { id, ...memberData } = editingMember;
      
      // Clean up data to avoid sending undefined values which can cause issues with rules
      const dataToSave: any = {
        name: memberData.name,
        role: memberData.role,
        type: memberData.type,
        order: editingMember.order || (editingMember.id ? 0 : members.length + 1),
        createdAt: editingMember.createdAt || Date.now(),
      };

      if (memberData.birthYear) dataToSave.birthYear = memberData.birthYear;
      if (memberData.deathYear) dataToSave.deathYear = memberData.deathYear;
      if (memberData.bio) dataToSave.bio = memberData.bio;
      if (memberData.photoUrl) dataToSave.photoUrl = memberData.photoUrl;
      if (memberData.gender) dataToSave.gender = memberData.gender;
      if (memberData.gallery) dataToSave.gallery = memberData.gallery;
      
      // Handle parentId and spouseId explicitly
      dataToSave.parentId = memberData.parentId || null;
      dataToSave.spouseId = memberData.spouseId || null;

      await setDoc(memberRef, dataToSave, { merge: true });
      setEditingMember(null);
      setMessage({ text: 'Member saved successfully!', type: 'success' });
    } catch (error: any) {
      console.error("Error saving member:", error);
      setMessage({ text: `Error saving member: ${error.message}`, type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'members', id));
      setDeleteConfirmId(null);
      setMessage({ text: 'Member deleted successfully!', type: 'success' });
    } catch (error) {
      console.error("Error deleting member:", error);
      setMessage({ text: 'Error deleting member', type: 'error' });
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: 'photoUrl' | 'gallery') => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Basic validation
    if (file.size > 5 * 1024 * 1024) {
      setMessage({ text: 'File is too large (max 5MB)', type: 'error' });
      return;
    }

    setUploading(true);
    setUploadProgress(10);
    
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          setUploadProgress(50);
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          // Max dimensions
          const MAX_WIDTH = 600;
          const MAX_HEIGHT = 600;
          
          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          // Compress to base64 JPEG
          const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
          
          setEditingMember(prev => {
            if (!prev) return prev;
            if (field === 'photoUrl') {
              return { ...prev, photoUrl: dataUrl };
            } else {
              return { 
                ...prev, 
                gallery: [...(prev?.gallery || []), dataUrl] 
              };
            }
          });
          
          setUploading(false);
          setUploadProgress(100);
          setMessage({ text: 'Image processed successfully!', type: 'success' });
          
          // Reset progress after a short delay
          setTimeout(() => setUploadProgress(0), 1000);
        };
        img.onerror = (error) => {
          console.error("Image load error:", error);
          setMessage({ text: 'Error processing image.', type: 'error' });
          setUploading(false);
        };
      };
      reader.onerror = (error) => {
        console.error("File read error:", error);
        setMessage({ text: 'Error reading file.', type: 'error' });
        setUploading(false);
      };
    } catch (error: any) {
      console.error("Error setting up upload:", error);
      setMessage({ text: `Error: ${error.message}`, type: 'error' });
      setUploading(false);
    }
  };

  const removeGalleryImage = (index: number) => {
    setEditingMember(prev => {
      if (!prev || !prev.gallery) return prev;
      const newGallery = [...prev.gallery];
      newGallery.splice(index, 1);
      return { ...prev, gallery: newGallery };
    });
  };

  const handleSeedData = async () => {
    setLoading(true);
    try {
      const demoMembers: Partial<Member>[] = [
        { name: 'রহিম উদ্দিন', role: 'দাদা', type: 'grandpa', order: 1, gender: 'male', createdAt: Date.now() },
        { name: 'ফাতেমা বেগম', role: 'দাদি', type: 'grandma', order: 2, gender: 'female', createdAt: Date.now() + 1 },
        { name: 'বড় ছেলে', role: 'ছেলে ১', type: 'son', order: 1, gender: 'male', createdAt: Date.now() + 2 },
        { name: 'মেজো ছেলে', role: 'ছেলে ২', type: 'son', order: 2, gender: 'male', createdAt: Date.now() + 3 },
        { name: 'বড় মেয়ে', role: 'মেয়ে ১', type: 'daughter', order: 3, gender: 'female', createdAt: Date.now() + 4 },
      ];

      for (const m of demoMembers) {
        await setDoc(doc(collection(db, 'members')), m);
      }
      setMessage({ text: 'Demo data added successfully!', type: 'success' });
    } catch (error) {
      console.error("Error seeding data:", error);
      setMessage({ text: 'Error adding demo data', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#EAE6DF] border-t-[#1A3636]"></div>
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-6xl mx-auto py-8 px-4"
    >
      <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
        <motion.h1 
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="text-3xl font-serif font-bold text-[#1A3636]"
        >
          Admin Dashboard
        </motion.h1>
        <div className="flex gap-4">
          {members.length === 0 && (
            <button 
              onClick={handleSeedData}
              className="flex items-center gap-2 bg-[#C19A6B] text-white px-4 py-2 rounded-lg hover:bg-[#a88358] transition-colors"
            >
              Seed Demo Data
            </button>
          )}
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setEditingMember({ type: 'son', order: 0, gender: 'male' })}
            className="flex items-center gap-2 bg-[#1A3636] text-white px-4 py-2 rounded-lg hover:bg-[#1C1816] transition-colors"
          >
            <Plus className="w-5 h-5" />
            Add Member
          </motion.button>
        </div>
      </div>

      <AnimatePresence>
        {message && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`mb-6 p-4 rounded-xl text-center font-medium shadow-sm border ${
              message.type === 'success' ? 'bg-green-50 text-green-700 border-green-100' : 'bg-red-50 text-red-700 border-red-100'
            }`}
          >
            {message.text}
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deleteConfirmId && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white p-6 rounded-3xl max-w-sm w-full shadow-2xl"
            >
              <h3 className="text-xl font-serif font-bold text-[#1A3636] mb-2">Confirm Delete</h3>
              <p className="text-[#736B65] mb-6">Are you sure you want to delete this family member? This action cannot be undone.</p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 py-2.5 border border-[#d8d2c9] rounded-full hover:bg-[#F9F8F6] font-medium transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => deleteConfirmId && handleDelete(deleteConfirmId)}
                  className="flex-1 py-2.5 bg-red-500 text-white rounded-full hover:bg-red-600 font-medium transition-colors"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {editingMember && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white p-6 rounded-3xl shadow-lg mb-8 border border-[#EAE6DF] overflow-hidden"
          >
            <div className="flex justify-between items-center mb-6 border-b border-[#EAE6DF] pb-4">
              <h2 className="text-2xl font-serif font-bold text-[#1A3636]">
                {editingMember.id ? 'Edit Member' : 'New Member'}
              </h2>
              <button onClick={() => setEditingMember(null)} className="text-[#C19A6B] hover:text-[#a88358] transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Full Name *</label>
              <input 
                type="text" 
                value={editingMember.name || ''} 
                onChange={e => setEditingMember({...editingMember, name: e.target.value})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Role (e.g. দাদা, ছেলে ১) *</label>
              <input 
                type="text" 
                value={editingMember.role || ''} 
                onChange={e => setEditingMember({...editingMember, role: e.target.value})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Type *</label>
              <select 
                value={editingMember.type || 'son'} 
                onChange={e => setEditingMember({...editingMember, type: e.target.value as any})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
              >
                <option value="grandpa">Grandpa (দাদা)</option>
                <option value="grandma">Grandma (দাদি)</option>
                <option value="son">Son (ছেলে)</option>
                <option value="daughter">Daughter (মেয়ে)</option>
                <option value="spouse">Spouse (স্ত্রী/স্বামী)</option>
                <option value="grandchild">Grandchild (নাতি/নাতনি)</option>
                <option value="great-grandchild">Great Grandchild (নাতি/নাতনির সন্তান)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Gender</label>
              <select 
                value={editingMember.gender || 'male'} 
                onChange={e => setEditingMember({...editingMember, gender: e.target.value as any})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
            
            {(editingMember.type === 'grandchild' || editingMember.type === 'great-grandchild') && (
              <div>
                <label className="block text-sm font-medium text-[#1A3636] mb-1">
                  {editingMember.type === 'grandchild' ? 'Parent (Son/Daughter)' : 'Parent (Grandchild)'}
                </label>
                <select 
                  value={editingMember.parentId || ''} 
                  onChange={e => setEditingMember({...editingMember, parentId: e.target.value})}
                  className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
                >
                  <option value="">Select Parent</option>
                  {members
                    .filter(m => editingMember.type === 'grandchild' ? (m.type === 'son' || m.type === 'daughter') : m.type === 'grandchild')
                    .map(m => (
                    <option key={m.id} value={m.id}>{m.name || m.role}</option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Spouse (Optional)</label>
              <select 
                value={editingMember.spouseId || ''} 
                onChange={e => setEditingMember({...editingMember, spouseId: e.target.value})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
              >
                <option value="">Select Spouse</option>
                {members.filter(m => m.id !== editingMember.id).map(m => (
                  <option key={m.id} value={m.id}>{m.name || m.role}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Birth Year</label>
              <input 
                type="text" 
                value={editingMember.birthYear || ''} 
                onChange={e => setEditingMember({...editingMember, birthYear: e.target.value})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Death Year (Optional)</label>
              <input 
                type="text" 
                value={editingMember.deathYear || ''} 
                onChange={e => setEditingMember({...editingMember, deathYear: e.target.value})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Order (Sorting)</label>
              <input 
                type="number" 
                value={editingMember.order || 0} 
                onChange={e => setEditingMember({...editingMember, order: parseInt(e.target.value)})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6]"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Bio / Info</label>
              <textarea 
                value={editingMember.bio || ''} 
                onChange={e => setEditingMember({...editingMember, bio: e.target.value})}
                className="w-full p-2.5 border border-[#d8d2c9] rounded-xl focus:ring-2 focus:ring-[#1A3636] outline-none bg-[#F9F8F6] h-24"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Profile Photo</label>
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-4">
                  {editingMember.photoUrl && (
                    <img src={editingMember.photoUrl} alt="Preview" className="w-14 h-14 rounded-full object-cover border-2 border-[#EAE6DF]" referrerPolicy="no-referrer" />
                  )}
                  <label className="cursor-pointer bg-[#EAE6DF] text-[#1A3636] px-4 py-2 rounded-full hover:bg-[#d8d2c9] transition-colors flex items-center gap-2 font-medium">
                    <ImageIcon className="w-4 h-4" />
                    {uploading ? 'Uploading...' : 'Upload Photo'}
                    <input type="file" accept="image/*" className="hidden" onChange={e => handleImageUpload(e, 'photoUrl')} disabled={uploading} />
                  </label>
                </div>
                {uploading && uploadProgress > 0 && uploadProgress < 100 && (
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                    <div className="bg-[#1A3636] h-1.5 rounded-full transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#1A3636] mb-1">Gallery Photos</label>
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-4 flex-wrap">
                  {editingMember.gallery?.map((url, i) => (
                    <div key={i} className="relative group">
                      <img src={url} alt="Gallery" className="w-14 h-14 rounded-xl object-cover border-2 border-[#EAE6DF]" referrerPolicy="no-referrer" />
                      <button 
                        onClick={() => removeGalleryImage(i)}
                        className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  <label className="cursor-pointer bg-[#EAE6DF] text-[#1A3636] px-4 py-2 rounded-full hover:bg-[#d8d2c9] transition-colors flex items-center gap-2 font-medium">
                    <ImageIcon className="w-4 h-4" />
                    {uploading ? 'Uploading...' : 'Add to Gallery'}
                    <input type="file" accept="image/*" className="hidden" onChange={e => handleImageUpload(e, 'gallery')} disabled={uploading} />
                  </label>
                </div>
                {uploading && uploadProgress > 0 && uploadProgress < 100 && (
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                    <div className="bg-[#1A3636] h-1.5 rounded-full transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mt-8 flex justify-end gap-4 border-t border-[#EAE6DF] pt-6">
            <button 
              onClick={() => setEditingMember(null)}
              className="px-6 py-2.5 border border-[#d8d2c9] rounded-full hover:bg-[#F9F8F6] text-[#736B65] transition-colors font-medium"
            >
              Cancel
            </button>
            <button 
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 px-6 py-2.5 bg-[#1A3636] text-white rounded-full hover:bg-[#1C1816] transition-colors font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Save className="w-4 h-4" />
              )}
              {saving ? 'Saving...' : 'Save Member'}
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>

      <div className="bg-white rounded-3xl shadow-sm border border-[#EAE6DF] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-[#F9F8F6] border-b border-[#EAE6DF] text-[#1A3636]">
                <th className="p-4 font-serif font-bold">Photo</th>
                <th className="p-4 font-serif font-bold">Name</th>
                <th className="p-4 font-serif font-bold">Role</th>
                <th className="p-4 font-serif font-bold">Type</th>
                <th className="p-4 font-serif font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {members.map(member => (
                <motion.tr 
                  key={member.id} 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="border-b border-[#EAE6DF] hover:bg-[#F9F8F6] transition-colors"
                >
                  <td className="p-4">
                    <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-[#EAE6DF] bg-[#F9F8F6] flex items-center justify-center">
                      {member.photoUrl ? (
                        <img src={member.photoUrl} alt={member.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <img 
                          src={`https://api.dicebear.com/9.x/${member.gender === 'female' ? 'lorelei' : 'micah'}/svg?seed=${encodeURIComponent(member.name || member.role)}&backgroundColor=EAE6DF`} 
                          alt="Avatar" 
                          className="w-full h-full object-cover p-0.5" 
                        />
                      )}
                    </div>
                  </td>
                  <td className="p-4 font-medium text-[#1A3636]">{member.name}</td>
                  <td className="p-4 text-[#736B65]">{member.role}</td>
                  <td className="p-4">
                    <span className="px-3 py-1 bg-[#EAE6DF] text-[#1A3636] rounded-full text-xs font-medium border border-[#d8d2c9]">
                      {member.type}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button 
                        onClick={() => handleMove(members.indexOf(member), 'up')}
                        disabled={members.indexOf(member) === 0}
                        className="p-2 text-[#C19A6B] hover:bg-[#C19A6B]/10 rounded-full transition-colors disabled:opacity-30"
                        title="Move Up"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleMove(members.indexOf(member), 'down')}
                        disabled={members.indexOf(member) === members.length - 1}
                        className="p-2 text-[#C19A6B] hover:bg-[#C19A6B]/10 rounded-full transition-colors disabled:opacity-30"
                        title="Move Down"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setEditingMember(member)}
                        className="p-2 text-[#1A3636] hover:bg-[#EAE6DF] rounded-full transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setDeleteConfirmId(member.id)}
                        className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
              {members.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-[#888] italic">
                    No family members found. Add one to get started!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
