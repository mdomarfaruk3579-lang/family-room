export interface Member {
  id: string;
  name: string;
  role: string;
  birthYear?: string;
  deathYear?: string;
  bio?: string;
  photoUrl?: string;
  gallery?: string[];
  type: string; // 'grandpa', 'grandma', 'son', 'daughter', 'spouse', 'grandchild', etc.
  parentId?: string | null;
  spouseId?: string | null;
  gender?: 'male' | 'female';
  order: number;
  createdAt?: number;
}

export interface User {
  uid: string;
  email: string | null;
  role: 'admin' | 'user';
}

export interface AboutPost {
  id: string;
  title: string;
  content: string;
  photoUrl?: string;
  createdAt: number;
  order: number;
}
