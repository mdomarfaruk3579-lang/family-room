import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './AuthContext';
import Home from './pages/Home';
import Admin from './pages/Admin';
import Profile from './pages/Profile';
import Gallery from './pages/Gallery';
import Statistics from './pages/Statistics';
import AboutUs from './pages/AboutUs';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import BackgroundAnimation from './components/BackgroundAnimation';

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-[#F7F5F0] text-[#2A2421] font-sans relative flex flex-col">
          <BackgroundAnimation />
          <Navbar />
          <main className="flex-grow p-4 md:p-8 relative z-10">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/member/:id" element={<Profile />} />
              <Route path="/gallery" element={<Gallery />} />
              <Route path="/statistics" element={<Statistics />} />
              <Route path="/about" element={<AboutUs />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}
