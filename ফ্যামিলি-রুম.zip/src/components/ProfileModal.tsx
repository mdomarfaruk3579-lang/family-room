import { motion, AnimatePresence } from 'framer-motion';
import { Member } from '../types';
import { X, Calendar, Info, Image as ImageIcon } from 'lucide-react';

interface ProfileModalProps {
  member: Member | null;
  onClose: () => void;
}

export default function ProfileModal({ member, onClose }: ProfileModalProps) {
  if (!member) return null;

  const seed = encodeURIComponent(member.name || member.role || 'family');
  const avatarUrl = `https://api.dicebear.com/9.x/micah/svg?seed=${seed}&backgroundColor=f9f6f0`;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-[#F7F4EB] rounded-[2rem] shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-[#E8E3D5]"
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-[#E8E3D5] hover:bg-[#D7CCC8] rounded-full transition-colors z-10 text-[#6D4C41]"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="p-8 sm:p-10">
            <div className="flex flex-col sm:flex-row gap-8 items-center sm:items-start">
              <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-[#E8E3D5] shadow-lg shrink-0 bg-[#F9F6F0]">
                {member.photoUrl ? (
                  <img src={member.photoUrl} alt={member.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover p-2" />
                )}
              </div>
              
              <div className="flex-1 text-center sm:text-left">
                <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#4A3B32] mb-3">{member.name}</h2>
                <div className="inline-block px-5 py-1.5 bg-[#6D4C41] text-white rounded-full font-medium mb-5 tracking-wide text-sm shadow-sm">
                  {member.role}
                </div>
                
                <div className="flex flex-col gap-2 mb-4">
                  {member.birthYear && (
                    <div className="flex items-center gap-2 text-[#8D6E63] justify-center sm:justify-start">
                      <Calendar className="w-4 h-4" />
                      <span>জন্ম: {member.birthYear}</span>
                    </div>
                  )}
                  {member.deathYear && (
                    <div className="flex items-center gap-2 text-[#8D6E63] justify-center sm:justify-start">
                      <Calendar className="w-4 h-4" />
                      <span>মৃত্যু: {member.deathYear}</span>
                    </div>
                  )}
                </div>
                
                {member.bio && (
                  <div className="mt-6 text-[#5D4037] leading-relaxed">
                    <div className="flex items-center gap-2 font-semibold text-[#4A3B32] mb-2 justify-center sm:justify-start">
                      <Info className="w-4 h-4 text-[#6D4C41]" />
                      <span>সংক্ষিপ্ত তথ্য</span>
                    </div>
                    <p className="text-justify sm:text-left">{member.bio}</p>
                  </div>
                )}
              </div>
            </div>

            {member.gallery && member.gallery.length > 0 && (
              <div className="mt-10 pt-8 border-t border-[#E8E3D5]">
                <div className="flex items-center gap-2 font-semibold text-[#4A3B32] mb-6">
                  <ImageIcon className="w-5 h-5 text-[#6D4C41]" />
                  <span className="font-serif text-xl">ফ্যামিলি গ্যালারি</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {member.gallery.map((url, idx) => (
                    <div key={idx} className="aspect-square rounded-2xl overflow-hidden shadow-sm border border-[#E8E3D5]">
                      <img src={url} alt={`Gallery ${idx}`} className="w-full h-full object-cover hover:scale-110 transition-transform duration-700" referrerPolicy="no-referrer" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
