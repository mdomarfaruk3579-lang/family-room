import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#1A3636] text-[#EAE6DF] py-2 mt-auto border-t border-[#C19A6B]/20">
      <div className="max-w-7xl mx-auto px-4 flex flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 text-sm font-serif italic">
          <span>ফ্যামিলি রুম</span>
          <Heart className="w-3 h-3 text-red-400 fill-red-400" />
        </div>
        <div className="text-[9px] opacity-80 tracking-wider font-medium uppercase">
          Created by : <span className="text-[#C19A6B]">Md Omars</span>
        </div>
        <div className="text-[8px] opacity-40">
          © {new Date().getFullYear()}
        </div>
      </div>
    </footer>
  );
}
