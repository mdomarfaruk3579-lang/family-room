import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { loginWithGoogle, logout } from '../firebase';
import { LogOut, Settings, Users, Home, Image as ImageIcon, Info } from 'lucide-react';

import { motion } from 'framer-motion';

export default function Navbar() {
  const { user, isAdmin } = useAuth();

  const handleLogoClick = (e: React.MouseEvent) => {
    if (!user) {
      e.preventDefault();
      loginWithGoogle();
    }
  };

  return (
    <motion.nav 
      initial={{ y: -50 }}
      animate={{ y: 0 }}
      className="bg-[#1A3636]/95 backdrop-blur-md text-white shadow-lg border-b border-[#EAE6DF]/10 px-2 sm:px-4 py-3 flex justify-between items-center sticky top-0 z-50"
    >
      <Link 
        to="/" 
        onClick={handleLogoClick}
        className="flex items-center gap-1.5 sm:gap-2 font-serif font-bold tracking-wide hover:text-[#C19A6B] transition-colors group"
      >
        <motion.div whileHover={{ rotate: 360 }} transition={{ duration: 0.5 }}>
          <Users className="w-5 h-5 sm:w-6 sm:h-6" />
        </motion.div>
        <span className="text-sm sm:text-2xl">ফ্যামিলি রুম</span>
      </Link>
      
      <div className="flex items-center gap-4 sm:gap-8">
        <div className="flex items-center gap-3 sm:gap-6 font-medium text-xs sm:text-base">
          <Link to="/" className="flex items-center gap-1 hover:text-[#C19A6B] transition-colors relative group">
            <Home className="w-4 h-4 sm:w-5 sm:h-5" /> <span className="hidden sm:inline">হোম</span>
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#C19A6B] transition-all group-hover:w-full"></span>
          </Link>
          <Link to="/gallery" className="flex items-center gap-1 hover:text-[#C19A6B] transition-colors relative group">
            <ImageIcon className="w-4 h-4 sm:w-5 sm:h-5" /> <span className="hidden sm:inline">গ্যালারি</span>
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#C19A6B] transition-all group-hover:w-full"></span>
          </Link>
          <Link to="/about" className="flex items-center gap-1 hover:text-[#C19A6B] transition-colors relative group">
            <Info className="w-4 h-4 sm:w-5 sm:h-5" /> <span className="hidden sm:inline">আমাদের সম্পর্কে</span>
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#C19A6B] transition-all group-hover:w-full"></span>
          </Link>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          {isAdmin && (
            <Link to="/admin" className="flex items-center gap-1 hover:text-[#C19A6B] transition-colors text-xs sm:text-base">
              <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="hidden sm:inline">অ্যাডমিন</span>
            </Link>
          )}
          
          {user && (
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={logout}
              className="flex items-center gap-1 text-[#EAE6DF] hover:text-red-300 transition-colors text-xs sm:text-base"
            >
              <LogOut className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="hidden sm:inline">লগআউট</span>
            </motion.button>
          )}
        </div>
      </div>
    </motion.nav>
  );
}

